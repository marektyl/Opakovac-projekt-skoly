
<!doctype html>
<html lang="en">
<title>Úvodní stránka</title>
    <style>
      .navbar-marg
      {
        margin-bottom: 25px;
      }
      .uprostred
      {
        text-align: center;
      }
    </style>

    <body>
        <div class= "container">
        <br /><br /><br /> 
        <h1 class="uprostred">Školy</h1>
        <br /><br /><br /> 
        <p class="uprostred">zde bude tabulka a mapa</p>
    </body>
</html>