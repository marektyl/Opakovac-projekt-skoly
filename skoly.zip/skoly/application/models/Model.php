<?php

class Model extends CI_model

{
    public function __construct() {
        parent::__construct();
    }


    public function vypis_skoly()  
    {  
         $query = $this->db->query("SELECT * FROM skola ORDER BY id ASC");  
         return $query->result();  
    }  


}

