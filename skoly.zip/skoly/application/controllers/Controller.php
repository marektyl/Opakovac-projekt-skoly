<?php
defined('BASEPATH') OR exit ('No direct script acces allowed');


class Controller extends CI_Controller
{
   public function __construct() {
      parent::__construct();
      $this->load->library('ion_auth');
      $this->load->model('Model');
      $this->load->view('pages/header');

      if(!$this->ion_auth->logged_in())$this->load->view('pages/menu'); //když nejsem přihlášen ->menu
      else if($this->ion_auth->logged_in() && $this->ion_auth->is_admin())$this->load->view('pages/menu_admin'); //když jsem přihlášen a jsem admin ->menu_admin
   }

   
  public function index()
  {
    if(!$this->ion_auth->logged_in())$this->load->view("pages/home");
    else if($this->ion_auth->logged_in() && $this->ion_auth->is_admin())$this->load->view('pages/home_admin');
  }
 
public function formular()
{
     $this->load->view('pages/formular');
}
     
}

